package com.leetu.dubbo.provider.impl;

import com.leetu.dubbo.api.DemoService;

/**
 * 服务提供方实现接口
 *
 */
public class DemoServiceImpl implements DemoService {

	@Override
	public String sayHello(String name) {
		return "Hello " + name;
	}

}
